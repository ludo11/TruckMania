<?php require('layout.php'); ?>

<h3>Connexion Foodtruck</h3>

    <p>
        <form method="POST" action="/">
            <input type='submit' name='home' class='submit-home' value='Home'>
        </form>
    </p>
<br>

<form method="POST" action="/connexion-foodtruck">
    <p>
        <label for='logInMail'>E-mail</label>
        <input type='email' name='logInMail' class='logIn_mail'>
    </p>
    <p>
        <label for='logInPassword'>Password</label>
        <input type='password' name='logInPassword' class='logIn_password'>
    </p>
    <p>
        <input type='submit' name='profile' class='submit-profile' value='Envoyer'>
    </p>
</form>



