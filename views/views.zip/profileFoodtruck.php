<?php session_start();?>
<h3>Mon Profil Foodtruck</h3>
    <p>
        <form method="POST" action="/">
            <input type='submit' name='home' class='submit-home' value='Home'>
        </form>
    </p>
<br>

<section>
    <article>
        <h4>Infos Persos: </h4>
        <p>
            Nom de l'entreprise: <?php echo $_SESSION['nom_entreprise']?><br>
            Nom: <?php echo $_SESSION['nom_entreprise']?><br>
            Prénom: <?php echo $_SESSION['prenom']?><br>
            E-mail: <?php echo $_SESSION['email']?><br>
            Adresse: <?php echo $_SESSION['siret']?><br>
            Numéro de téléphone: <?php echo $_SESSION['nom_entreprise']?><br>
            Numéro de siret: <?php echo $_SESSION['password']?><br>
        </p>
    </artcile>    
</section>



