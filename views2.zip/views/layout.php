
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
    <link rel="shortcut icon" href="/images/gt_favicon.png">
	 <script src='https://api.tiles.mapbox.com/mapbox-gl-js/v0.46.0/mapbox-gl.js'></script>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v0.46.0/mapbox-gl.css' rel='stylesheet' />
    <style>
        body { margin:0; padding:0; }
        #map { position:absolute; top:0; bottom:0; width:100%; }
    </style>
	<!-- Bootstrap itself -->
	<link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/magister.css">
 
  
	<!-- Custom styles -->
	
        

	<!-- Fonts -->

	
      <meta name="viewport" content="width=device-width, initial-scale=1">  
   
        <meta charset="UTF-8">
        <title>Projet</title>
    </head>
    <body class="theme-invert">
       

            <header>
            
            <nav id="mainmenu">
                   <div class="container">

                       <div class="dropdown" id="menu">

                           <nav class="navbar navbar-expand-lg navbar  fixed-top" id="menu">
                                   <ul class="nav nav-pills" role="menu" aria-labelledby="dLabel"  id="menu">
                                           <li><a href="/" class="active">Accueil</a></li>
                                           <li><a href="/race" class="active">Espace CLient</a></li>
                                           <li><a href="/espace-pros">Espace Pros</a></li>
                                           <li><a href="/espace-foodtruck" class="active">Espace FoodTrucks</a></li>
                                           <li><a href="/chatons">Carte</a></li>
<!--                                           <li><a href="/contact">Contactez-nous</a></li>-->
                                            <form class="form-inline" method="POST" action="/search">
                                                <input class="form-control mr-sm-2" type="search" name="search" placeholder="Rechercher par ville" aria-label="Rechercher par ville">
                                                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Rechercher</button>
                                            </form>
                                   </ul>
                                </nav>
                           </div>
                   </div>
           </nav>
         </header>
<!-- Fourth (Contact) section -->
    

            
<!-- Load js libs only when the page is loaded. -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
<!-- Footer -->

<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<script src="assets/js/modernizr.custom.72241.js"></script>
<!-- Custom template scripts -->
<script src="assets/js/magister.js"></script>
</body>
</html>
