<?php require 'layout.php'; ?>


<div class="row" >
<?php
//                  var_dump($datas);

foreach ($foods as $food) {
    ?>
<div class="card" style="width: 18rem;" id="listeFoodTruck">
        <img class="card-img-top" src="../images/food-truck-new-york-food-street-food-brooklyn-food-porn-1.gif" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title">
     <?php echo var_dump($food->getID()); ?> </h5>
            <p class="card-text"><?php echo $food->getNom_entreprise(); ?></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?php echo $food->getNom(); ?> euros</li>
            <li class="list-group-item"><?php echo $food->getVilles_nom_villes(); ?></li>
            <li class="list-group-item">Vestibulum at eros</li>
        </ul>
        <div class="card-body">
            <a class="btn btn-primary" href="/infoFoodTruck/<?php echo $food->getID() ?>" role="button">Link</a>
        </div>
    </div>



    <?php } ?>
</div>
<footer>
<?php include 'footer.php'; ?>
</footer>