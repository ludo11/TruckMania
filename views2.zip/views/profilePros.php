<?php require 'layout.php'; ?>

<br><br><br><br><br><br><br><br>

<h3>Mon Profil Pros</h3>
    
<br>

<section>
    <article>
        <h4>Infos Persos: </h4>
        <p>
            Nom de l'entreprise: <?php echo $_SESSION['nom_entreprise']?><br>
            Nom: <?php echo $_SESSION['nom_entreprise']?><br>
            Prénom: <?php echo $_SESSION['prenom']?><br>
            E-mail: <?php echo $_SESSION['email']?><br>
            Adresse: <?php echo $_SESSION['n_siret']?><br>
            Numéro de téléphone: <?php echo $_SESSION['nom_entreprise']?><br>
            Numéro de siret: <?php echo $_SESSION['password']?><br>
        </p>
    </artcile>    
</section>

<section>
    <article>
        <h4>Créer evenement (soumis a validation par administrateur)</h4>
        <p>
            <form method="POST" action="/espace-pros/creation-evenement">
    <p>
        <label for='eventName'>Nom de l'evenement</label>
        <input type='text' name='nom_event' class='business_name'>
    </p>
    <p>
        <label for='date_event'>Date</label>
        <input type='date' name='date_event' class='name'>
    </p>
    
     <p>
        <label for='adresse'>Adresse</label>
        <input type='text' name='adresse' class='name'>
    </p>
  
    <p>
        <input type='hidden' name='Pros_id' class='pass_word' value="<?php echo $_SESSION['id'] ?>">
    </p>
    <?php echo $_SESSION['id'] ?>
    <p>
        
        <label for='Villes_nom_villes'>Ville</label>
        <input type='text' name='Villes_nom_villes' class='ville'>
    </p>
    <p>
        <input type='hidden' name='role' class='pass_word' >
    </p>

    <p>
   <p>
        <input type='submit' name='Space' class='space-submit' value='Envoyer'>
    </p>
</form>
        </p>
    </artcile>    
</section>
<footer>
<?php include 'footer.php'; ?>
</footer>