


<?php require 'layout.php'; ?>

<br><br><br><br><br><br><br><br>
<h3>Espace Foodtruck</h3>

   
<br>
<a href="/espace-foodtruck/signUp" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Inscription</a>
<a href="/espace-foodtruck/login" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Login</a>



<footer>
<?php include 'footer.php'; ?>
</footer>