<?php require 'layout.php'; ?>

  
 
  
	<!-- Custom styles -->
	
        <section><br><br><br><br>
<h3>Inscription Foodtruck</h3>

<form method="POST" action="/inscription-pros">
    <p>
        <label for='businessName'>Nom de l'entreprise</label>
        <input type='text' name='businessName' class='business_name'>
    </p>
    <p>
        <label for='name'>Nom</label>
        <input type='text' name='name' class='name'>
    </p>
    <p>
        <label for='firstName'>Prénom</label>
        <input type='text' name='firstName' class='first_name'>
    </p>
    <p>
        <label for='password'>Mot de passe</label>
        <input type='password' name='password' class='pass_word'>
    </p>
    <p>
        <label for='verifPassword'>Vérifier mot de passe</label>
        <input type='password' name='verifPassword' class='verif_password'>
    </p>
    <p>
        <label for='email'>E-mail</label>
        <input type='email' name='email' class='email'>
    </p>
    <p>
        <label for='tel'>Numéro de téléphone</label>
        <input type='tel' name='tel' class='tel'>
    </p>
    <p>
        <label for='siretNumber'>Numéro de siret</label>
        <input type='text' name='siretNumber' class='siret_number'>
    </p>
    <p>
        <label for='ville'>Ville</label>
        <input type='text' name='ville' class='address'>
    </p>
    <p>
        <input type='submit' name='Space' class='space-submit' value='Envoyer'>
    </p>
</form>
</section>
<footer>
<?php include 'footer.php'; ?>
</footer>
<?php 

