<?php require 'layout.php'; ?>


<div class="row" >
<?php
//                  var_dump($datas);

foreach ($datas as $food) {
    ?>
 <div id='map'>
<script>
mapboxgl.accessToken = 'pk.eyJ1IjoiY2xlbWVudGJld2ViIiwiYSI6ImNqaXB4aWt2ZTE1bHMza21oM3h3azdzMWQifQ.RmIvZ3g2BNCdYcTmZZ44_Q';
var map = new mapboxgl.Map({
    container: 'map', // container id
    style: 'mapbox://styles/mapbox/streets-v9',
    center: [-96, 37.8], // starting position
    zoom: 3 // starting zoom
});

// Add geolocate control to the map.
map.addControl(new mapboxgl.GeolocateControl({
    positionOptions: {
        enableHighAccuracy: true
    },
    trackUserLocation: true
}));
map.on('click', function(e) {
     //JSON.stringify(e.point) + '<br />' +
        // e.lngLat is the longitude, latitude geographical position of the event
        JSON.stringify(e.lngLat);
    map.loadImage('https://upload.wikimedia.org/wikipedia/commons/3/31/Icone_maps.png', function(error, image) {
        if (error) throw error;
        map.addImage('icon', image);
        map.addLayer({
            "id": "points",
            "type": "symbol",
            "source": {
                "type": "geojson",
                "data": {
                    "type": "FeatureCollection",
                    "features": [{
                        "type": "Feature",
                        "properties": {
                        "description": "<strong>Ballston Arts & Crafts Market</strong><p>The <a href=\"http://ballstonarts-craftsmarket.blogspot.com/\" target=\"_blank\" title=\"Opens in a new window\">Ballston Arts & Crafts Market</a> sets up shop next to the Ballston metro this Saturday for the first of five dates this summer. Nearly 35 artists and crafters will be on hand selling their wares. 10:00-4:00 p.m.</p>",
                        "icon": "art-gallery"
                    },
                        "geometry": {
                            "type": "Point",
                            "coordinates": [ e.lngLat.lng, e.lngLat.lat]
                        }
                        
                    }]
                }
            },
            "layout": {
                "icon-image": "icon",
                "icon-allow-overlap": true,
                "icon-size": 0.05
            }
            
        });
        // When a click event occurs on a feature in the places layer, open a popup at the
    // location of the feature, with description HTML from its properties.
    map.on('click', 'places', function (e) {
        var coordinates = e.features[0].geometry.coordinates.slice();
        var description = e.features[0].properties.description;

        // Ensure that if the map is zoomed out such that multiple
        // copies of the feature are visible, the popup appears
        // over the copy being pointed to.
        while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
            coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
        }

        new mapboxgl.Popup()
            .setLngLat(coordinates)
            .setHTML(description)
            .addTo(map);
    });

    // Change the cursor to a pointer when the mouse is over the places layer.
    map.on('mouseenter', 'places', function () {
        map.getCanvas().style.cursor = 'pointer';
    });

    // Change it back to a pointer when it leaves.
    map.on('mouseleave', 'places', function () {
        map.getCanvas().style.cursor = '';
    });
        
        
        
        
    });
});


</script>
 </div>
<div class="card" style="width: 18rem;" id="idFoodTruck">
        <img class="card-img-top" src="../images/food-truck-new-york-food-street-food-brooklyn-food-porn-1.gif" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title">
     <?php echo var_dump($food->getID()); ?> </h5>
            <p class="card-text"><?php echo $food->getNom_entreprise(); ?></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?php echo $food->getNom(); ?> euros</li>
            <li class="list-group-item"><?php echo $food->getVilles_nom_villes(); ?></li>
   
        </ul>
        <div class="card-body">
            <a class="btn btn-primary" href="/infoFoodTruck/<?php echo $food->getID() ?>" role="button">Link</a>
        </div>
    </div>
<?php } ?>
    <footer id="footerIdTruck">
<?php include 'footer.php'; ?>
</footer>
